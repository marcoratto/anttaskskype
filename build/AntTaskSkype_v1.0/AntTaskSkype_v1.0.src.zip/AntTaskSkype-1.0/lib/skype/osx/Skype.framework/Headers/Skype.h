// $Id: Skype.h,v 1.2 2005/06/15 11:13:05 teelem Exp $
/*
 *  Skype.h
 *  SkypeMac
 *
 *  Created by Janno Teelem on 12/04/2005.
 *  Copyright (c) 2005 Skype Technologies S.A. All rights reserved.
 *
 */

#include "SkypeAPI-Carbon.h"

#ifdef __OBJC__
	#include "SkypeAPI.h"
#endif

